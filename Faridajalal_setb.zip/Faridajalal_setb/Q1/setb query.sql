create table Participantdetailss_172312
  (
  VoucherNumber int IDENTITY(100,1) PRIMARY KEY ,
ParticipantName VARCHAR(50) NOT NULL,
Technology VARCHAR(50) NOT NULL,
CertificationCode VARCHAR(50) NOT NULL,
CertificationName VARCHAR(50) NOT NULL,
CertificationDate DATETIME NOT NULL
)

insert into Participantdetailss_172312 values ('Robert','microsoft',70461,'querying microsoftsqlserver',1/2/2018)

select*from Participantdetailss_172312


CREATE PROCEDURE SP_ADD_ParticipantDetailss_172312
  @VoucherNumber bigint,
  @ParticipantName varchar(50),
  @Technology varchar(50),
  @CertificationCode varchar(50),
  @CertificationName  varchar(50),
  @CertificationDate datetime
  as
  begin
  insert into Participantdetailss_172312 values ( @ParticipantName ,@Technology,@CertificationCode, @CertificationName,@CertificationDate )
  set  @VoucherNumber=scope_IDENTITY()
  END
 
 create procedure SP_SEARCH_ParticipantDetailss_172312 
  @VoucherNumber bigint
  AS
  BEGIN
  SELECT*FROM Participantdetailss_172312 WHERE VoucherNumber= @VoucherNumber
  END
  EXEC SP_SEARCH_ParticipantDetails_172312 1231
  


 create table Participantdetailss_172312
  (
  VoucherNumber int IDENTITY(100,1) PRIMARY KEY ,
ParticipantName VARCHAR(50) NOT NULL,
Technology VARCHAR(50) NOT NULL,
CertificationCode VARCHAR(50) NOT NULL,
CertificationName VARCHAR(50) NOT NULL,
CertificationDate DATETIME NOT NULL
)

insert into Participantdetailss_172312 values ('Robert','microsoft',70461,'querying microsoftsqlserver',1/2/2018)

select*from Participantdetailss_172312
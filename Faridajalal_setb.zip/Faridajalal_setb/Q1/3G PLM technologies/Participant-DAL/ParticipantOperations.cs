﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Participant_Entity;
using Participant_Exception;


namespace Participant_DAL
{
    public class ParticipantOperations
    {


        static string ConnectionString = GlobalData.ConnectionString;
        SqlConnection connection = new SqlConnection();

        public bool AddParticipantDAL(Participant newParticipant)
        {
            bool isparticipantadded = false;
            try
            { 
           
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "SP_ADD_ParticipantDetailss_172312";
                Command.Parameters.AddWithValue("@VoucherNumber", newParticipant.VoucherNumber);
                Command.Parameters.AddWithValue("@ParticipantName", newParticipant.ParticipantName);
                Command.Parameters.AddWithValue("@Technology", newParticipant.Technology);
                Command.Parameters.AddWithValue("@CertificationCode", newParticipant.CertificationCode);
                Command.Parameters.AddWithValue("@CertificationName", newParticipant.CertificationName);
                Command.Parameters.AddWithValue("@CertificationDate", newParticipant.CertificationDate);
                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                int NumberOfRowsAdded = Command.ExecuteNonQuery();
                if (NumberOfRowsAdded == 1)
                    isparticipantadded = true;
            }
            catch (ParticipantEX)
            {
                throw;
            }
            return isparticipantadded;
        }

        public Participant SearchParticipantDAL(int SearchVoucherNumber)
        {
            Participant SearchedParticipant = new Participant();
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "SP_SEARCH_ParticipantDetailss_172312";
                Command.Parameters.AddWithValue("@VoucherNumber", SearchVoucherNumber);
                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                SqlDataReader Reader = Command.ExecuteReader();
                if (Reader.HasRows)
                {
                    while (Reader.Read())
                    {
                        SearchedParticipant.VoucherNumber =Reader[0].ToString();
                        SearchedParticipant.ParticipantName = Reader[1].ToString();
                        SearchedParticipant.Technology = Reader[2].ToString();
                        SearchedParticipant.CertificationCode = Reader[3].ToString();
                        SearchedParticipant.CertificationName = Reader[4].ToString();
                        SearchedParticipant.CertificationDate = DateTime.Parse(Reader[5].ToString());
                    }
                }
            }
            catch (ParticipantEX)
            {
                throw;
            }
            return SearchedParticipant;
        }


    }
}

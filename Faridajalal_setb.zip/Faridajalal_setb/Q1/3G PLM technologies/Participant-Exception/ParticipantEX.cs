﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Participant_Exception
{

    [Serializable]
    public class ParticipantEX : Exception
    {
        public ParticipantEX() { }
        public ParticipantEX(string message) : base(message) { }
        public ParticipantEX(string message, Exception inner) : base(message, inner) { }
        protected ParticipantEX(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
   
}

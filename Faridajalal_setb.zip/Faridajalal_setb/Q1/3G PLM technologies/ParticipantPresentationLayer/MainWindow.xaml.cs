﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Participant_Entity;
using Participant_Exception;
using ParticipantBLL;

namespace ParticipantPresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private static Participant SearchParticipantbynumber(int searchnumber)
        {
            Participant Searchedparticipant = new Participant();
            try
            {
                Searchedparticipant = ParticipantValidations.SearchParticipantBL(searchnumber);
            }
            catch (ParticipantEX ex)
            {
                MessageBox.Show(ex.Message);
            }
            return Searchedparticipant;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int VoucherNumber = int.Parse(txtvouchernum.Text);
            Participant SearchedParticipant = SearchParticipantbynumber(VoucherNumber);
            txtname.Text = SearchedParticipant.ParticipantName;
            txttech.Text = SearchedParticipant.Technology;
            txtcer.Text = SearchedParticipant.CertificationCode;
            txtpname.Text = SearchedParticipant.CertificationName;
            tbdate.DataContext = Convert.ToDateTime(SearchedParticipant.CertificationDate);






        }
    }


}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Participant_Entity;
using Participant_Exception;
using Participant_DAL;

namespace ParticipantBLL
{
    public class ParticipantValidations
    {
        private bool ValidParticipant(Participant newParticipant)
        {
            bool isvalidParticipant = true;
            StringBuilder sbClientError = new StringBuilder();
            if (newParticipant.VoucherNumber.Equals(string.Empty))//validation for voucher number
            {
                isvalidParticipant = false;
                sbClientError.Append("vorcher number should not be blank !!:)" + Environment.NewLine);
            }
           
            if (newParticipant.ParticipantName.Equals(string.Empty))
            {
                isvalidParticipant = false;
                sbClientError.Append("ParticipantName is  blank !!:)" + Environment.NewLine);
            }
          
            if (newParticipant.Technology.Equals(string.Empty))
            {
                isvalidParticipant = false;
                sbClientError.Append("Technology is  blank !!:)" + Environment.NewLine);
            }
            if (newParticipant.CertificationCode.Equals(string.Empty))
            {
                isvalidParticipant = false;
                sbClientError.Append("CertificationCode is  blank !!:)" + Environment.NewLine);
            }
            if (newParticipant.CertificationName.Equals(string.Empty))
            {
                isvalidParticipant = false;
                sbClientError.Append("CertificationName is  blank !!:)" + Environment.NewLine);
            }


            if (!isvalidParticipant)
            {
                throw new ParticipantEX(sbClientError.ToString());
            }
            return isvalidParticipant;
            
        }

        //public static bool AddParticipantBL(Participant newParticipant)

        //{
        //    bool ParticipantAdded = false;
        //    try
        //    {
        //        if (ValidParticipant(newParticipant))
        //        {
        //            ParticipantOperations ParticipantOperations = new ParticipantOperations();
        //            ParticipantAdded = ParticipantOperations.AddParticipantDAL(newParticipant);
        //        }
        //    }
        //    catch (ParticipantEX)
        //    {
        //        throw;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //    return ParticipantAdded;
        //}


        public static Participant SearchParticipantBL(int searchVouchernumber)
        {
            Participant searchParticipant = null;
            try
            {
                ParticipantOperations ParticipantOperations = new ParticipantOperations();
                searchParticipant = ParticipantOperations.SearchParticipantDAL(searchVouchernumber);
            }
            catch (ParticipantEX ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchParticipant;

        }
    }
}
